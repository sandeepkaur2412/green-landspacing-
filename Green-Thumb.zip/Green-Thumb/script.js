const testimonialsList = document.getElementById('testimonials-list');

fetch('testimonials.txt')
  .then(response => response.text())
  .then(text => {
    const reviews = text.split('\n');
    reviews.forEach(review => {
      const [name, rating, content, avatar] = review.split('|');
      const listItem = document.createElement('li');
      listItem.classList.add('testimonial');
      const avatarImg = document.createElement('img');
      avatarImg.src = avatar;
      const infoDiv = document.createElement('div');
      infoDiv.classList.add('info');
      const nameHeading = document.createElement('h3');
      nameHeading.textContent = name;
      const ratingSpan = document.createElement('span');
      ratingSpan.textContent = '★'.repeat(rating);
      const contentParagraph = document.createElement('p');
      contentParagraph.textContent = content;
      infoDiv.append(nameHeading, ratingSpan, contentParagraph);
      listItem.append(avatarImg, infoDiv);
      testimonialsList.append(listItem);
    });
  });
